import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {
    try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('d6eb6637-d0b6-470a-bb42-b33edd2198c8', '1Milton.Price96@yahoo.com', 'Jamie Doe', 'https://i.imgur.com/YfJQV5z.png?id=3', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('a456212f-c782-4cd3-a8cc-982db73c40b5', '7Hyman57@gmail.com', 'Chris Johnson', 'https://i.imgur.com/YfJQV5z.png?id=9', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab', '13Norma.Hammes@yahoo.com', 'Jamie Doe', 'https://i.imgur.com/YfJQV5z.png?id=15', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('bd5030a4-2b4f-40c1-8968-b13b58f97ce8', '19Annabelle_Schaden@yahoo.com', 'Chris Johnson', 'https://i.imgur.com/YfJQV5z.png?id=21', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('2d463773-5582-4e7b-be93-e883c3521f53', '25Jayda92@yahoo.com', 'Jamie Doe', 'https://i.imgur.com/YfJQV5z.png?id=27', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('09e03c7e-8963-4577-80f6-f45a84783a20', '31Junior_Schumm@gmail.com', 'Morgan Lee', 'https://i.imgur.com/YfJQV5z.png?id=33', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('a9b3986e-eca4-4d32-9f13-b127f093d3c3', '37Arlie_Schumm@yahoo.com', 'Alex Smith', 'https://i.imgur.com/YfJQV5z.png?id=39', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('a4967402-cfa5-4b1c-b6c2-3dc5249051ad', '43Juston_Feeney80@yahoo.com', 'Chris Johnson', 'https://i.imgur.com/YfJQV5z.png?id=45', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('50ec9851-d430-41f3-af1e-82510eb3d6ec', '55Immanuel.Zulauf@hotmail.com', 'Chris Johnson', 'https://i.imgur.com/YfJQV5z.png?id=57', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('873e36e5-5802-4320-a264-bc66ed9a50a5', 'Video Comment', 'You have a new friend request from Emily', 'Sarah', '64Shaniya.Krajcik@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=65', 'https://i.imgur.com/YfJQV5z.png?id=66', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('03e45ad7-8ec7-4b63-bd04-76acfec760d1', 'Video Comment', 'You have a new friend request from Emily', 'Emily', '71Mario_Davis15@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=72', 'https://i.imgur.com/YfJQV5z.png?id=73', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('37c25c9b-fa33-4654-b4a4-22bcec9076fe', 'New Message', 'Your photo got a new like', 'Sarah', '78Daniela.Doyle3@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=79', 'https://i.imgur.com/YfJQV5z.png?id=80', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('734943e1-f72c-4ef4-ad25-67a069afa7b8', 'Video Comment', 'Your video received a new comment', 'Michael', '85Ima_Koch16@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=86', 'https://i.imgur.com/YfJQV5z.png?id=87', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('407ea760-2679-4d5a-8bc9-1b2c70ae2619', 'New Friend Request', 'You have a new friend request from Emily', 'John', '92Twila54@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=93', 'https://i.imgur.com/YfJQV5z.png?id=94', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('1689a710-d2d1-4251-8ba2-10e2a794c332', 'Like Alert', 'Someone just visited your profile', 'Emily', '99Magnolia_Muller-Bahringer20@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=100', 'https://i.imgur.com/YfJQV5z.png?id=101', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('2f446c2e-646f-4afe-92c5-fcdbc0f13d57', 'Video Comment', 'You received a new message from John.', 'Emily', '106Destin48@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=107', 'https://i.imgur.com/YfJQV5z.png?id=108', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('3b2adc50-e25d-4096-aabe-ec18220f6aee', 'New Message', 'Your photo got a new like', 'Alex', '113Eloise.Hilll@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=114', 'https://i.imgur.com/YfJQV5z.png?id=115', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9be4c4b9-5a9d-4bbe-8b3f-4f8ed640ebc2', 'Profile Visit', 'Your photo got a new like', 'Sarah', '120Flavie_Schamberger13@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=121', 'https://i.imgur.com/YfJQV5z.png?id=122', '35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e1b0389b-8388-4b5e-833b-548335de4ab6', 'Video Comment', 'Your video received a new comment', 'Alex', '127Carey54@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=128', 'https://i.imgur.com/YfJQV5z.png?id=129', '50ec9851-d430-41f3-af1e-82510eb3d6ec');

INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('657d5058-0de4-4829-9e5f-b3f55f7f7eca', 'PixelPioneer', 'Love capturing the unseen.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=133', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('41fe86df-1aaa-42fd-b5f4-948ab7e31478', 'StarGazer89', 'Finding magic in the mundane.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=137', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('7131b609-721d-4168-baac-4c111d37ad8a', 'MysticMeadow', 'Vintage heart modern dreams.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=141', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('1914fb46-285d-4fad-b230-2f3a88ce6f46', 'MysticMeadow', 'Crafting worlds beyond the stars.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=145', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('fe1a2f9c-fe24-4ecb-aa24-d783388cc5fd', 'PixelPioneer', 'Finding magic in the mundane.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=149', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('743f2fe5-d971-48bf-bfb6-255787cd1d49', 'StarGazer89', 'Finding magic in the mundane.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=153', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('790c3f85-e2e6-4e49-a296-c1cacf0c9711', 'PixelPioneer', 'Crafting worlds beyond the stars.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=157', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('1077b736-b9ec-4000-a908-894620008ff3', 'MysticMeadow', 'Finding magic in the mundane.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=161', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('e8fa6d68-2676-4ad1-9e05-9511060e20ea', 'PixelPioneer', 'Vintage heart modern dreams.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=165', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "profile" ("id", "username", "bio", "profilePictureUrl", "userId") VALUES ('bb5dccfa-3456-4463-84e7-481c682d606f', 'MysticMeadow', 'Crafting worlds beyond the stars.', 'https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf?id=169', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');

INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('0bc096c1-92f4-4ea8-af99-ffcb22b585ce', 'image', 'https://i.imgur.com/YfJQV5z.png?id=172', 'A breathtaking view of the night sky.', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('68a5a410-1ca5-4df4-a1a0-95edf7aef085', 'video', 'https://i.imgur.com/YfJQV5z.png?id=176', 'A breathtaking view of the night sky.', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('62f0ef05-05f0-4933-8b42-b8dee5529e06', 'image', 'https://i.imgur.com/YfJQV5z.png?id=180', 'A collection of the most adorable kittens.', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('1ad60e1e-5b63-4ab5-bed3-c04bb5c1d7ba', 'video', 'https://i.imgur.com/YfJQV5z.png?id=184', 'An exciting short film about friendship.', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('ee265cb4-e125-4719-9cb5-f5702bffafd2', 'video', 'https://i.imgur.com/YfJQV5z.png?id=188', 'An exciting short film about friendship.', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('5ca41e3e-a902-4e82-bae2-a21a0316fd47', 'video', 'https://i.imgur.com/YfJQV5z.png?id=192', 'Tutorial on how to play the guitar for beginners.', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('682353e8-d1df-4c92-887c-c779d7a82121', 'image', 'https://i.imgur.com/YfJQV5z.png?id=196', 'A collection of the most adorable kittens.', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('3580e0d7-377e-4802-ae15-aa924048f6ff', 'video', 'https://i.imgur.com/YfJQV5z.png?id=200', 'A breathtaking view of the night sky.', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('4b28d4ad-869f-46bb-b649-e187a16fe7f7', 'image', 'https://i.imgur.com/YfJQV5z.png?id=204', 'Tutorial on how to play the guitar for beginners.', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "content" ("id", "type", "url", "description", "userId") VALUES ('8476670d-790d-489a-ad6b-b302f92cec82', 'image', 'https://i.imgur.com/YfJQV5z.png?id=208', 'A beautiful sunset over the mountains.', '09e03c7e-8963-4577-80f6-f45a84783a20');

INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('feb2ecb3-a7a6-4ce3-90f9-0dfeaa1b2d33', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('19357aa8-6eef-4a34-9be4-b8f2e882b64c', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('ab9d230f-ad71-40e2-adf8-199558531238', '50ec9851-d430-41f3-af1e-82510eb3d6ec', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('a89d2d7b-9b74-4841-920a-2fcc03b1f82c', '50ec9851-d430-41f3-af1e-82510eb3d6ec', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('ae2e077e-3c21-4c32-8447-9f5e45c60be4', '2d463773-5582-4e7b-be93-e883c3521f53', '35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('514240d5-358a-45cf-866a-d402e80c1307', 'a456212f-c782-4cd3-a8cc-982db73c40b5', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('aa520bab-8a43-4d0f-93b2-4651052d4eb5', 'a456212f-c782-4cd3-a8cc-982db73c40b5', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('e0454421-3d96-4fe3-a0ff-40ab7ce35605', '50ec9851-d430-41f3-af1e-82510eb3d6ec', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('60046bbf-fbaf-4554-80dc-4e7c5ea9cae5', 'a456212f-c782-4cd3-a8cc-982db73c40b5', '35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab');
INSERT INTO "chat" ("id", "senderId", "receiverId") VALUES ('607c6c5f-6954-4d9f-8f64-222e4cf44739', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3', 'a456212f-c782-4cd3-a8cc-982db73c40b5');

INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('bab9ac08-5164-48cf-a138-34628dfc026b', 'Hey love your latest post', 'feb2ecb3-a7a6-4ce3-90f9-0dfeaa1b2d33', '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('aa415699-2f50-4bdd-a4f2-cc9fffaf9c63', 'What camera do you use for your photos', 'aa520bab-8a43-4d0f-93b2-4651052d4eb5', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('9cf07bda-6bae-44f3-bec1-af0c79dedbae', 'Hey love your latest post', 'feb2ecb3-a7a6-4ce3-90f9-0dfeaa1b2d33', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('78ce700e-52cb-4401-8a8a-6fbb9755ebfc', 'Do you have any tips for beginners', 'e0454421-3d96-4fe3-a0ff-40ab7ce35605', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('531c652f-dc29-4c03-ad37-f35b3f6bae49', 'That was an amazing video how did you edit it', 'e0454421-3d96-4fe3-a0ff-40ab7ce35605', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('5f49e43c-601e-4af8-a1ef-ecb3d810283f', 'That was an amazing video how did you edit it', 'feb2ecb3-a7a6-4ce3-90f9-0dfeaa1b2d33', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('adcb3cf6-8e52-44c4-a56a-efb13ca9c451', 'What camera do you use for your photos', '19357aa8-6eef-4a34-9be4-b8f2e882b64c', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('cbf4f74f-17de-43dd-aff8-be6bca2614e9', 'What camera do you use for your photos', '607c6c5f-6954-4d9f-8f64-222e4cf44739', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('99b6fd3f-c365-4a25-9bad-7c1cf961536d', 'Do you have any tips for beginners', 'ae2e077e-3c21-4c32-8447-9f5e45c60be4', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "message" ("id", "content", "chatId", "senderId") VALUES ('231317b7-cd1e-4045-8b50-0d030b80c9a2', 'Hey love your latest post', 'aa520bab-8a43-4d0f-93b2-4651052d4eb5', '50ec9851-d430-41f3-af1e-82510eb3d6ec');

INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('ab9889c2-61cb-452d-88f3-36904c545b26', 485, 31, 522, 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('1a7df8a1-c75f-474e-b184-4e5665c87791', 881, 968, 73, 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('cf24ad7e-4263-40e9-8f21-4c3a032888f4', 889, 373, 692, '35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('31e9ce02-7ce1-4a69-ad18-03d6c4fb23df', 666, 546, 952, 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('fb60bbd8-5325-43d9-bf3c-7128ef0f7d66', 796, 762, 97, 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('7fa61db8-626c-41ce-979f-915a074827ae', 854, 583, 702, '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('5aa4f8ec-4619-403e-8c81-a4c287932f80', 711, 59, 453, 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('8113a458-0f4d-494b-9a7e-4bf8e04d05fa', 224, 899, 418, 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('df65a593-ebe1-46e5-a53e-42fd269c012d', 669, 268, 856, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "vote" ("id", "weekOfYear", "year", "voteCount", "userId") VALUES ('291b085a-3f96-4900-8d68-48860be939f8', 910, 738, 485, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('fcd0b092-7a32-4e3c-b8d2-1816dd297213', 'QWE45P', 3, 141, 463, 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('734dc0b7-a784-4981-8e50-7d131a028abd', 'ASD67F', 327, 318, 118, '35fd3ad7-e78b-4b0e-8edb-5dd16acb0bab');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('4d987ec9-84b8-41b3-8eff-edb84b0b0b06', 'ASD67F', 944, 38, 369, '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('e46d3efc-1a99-40ac-bf81-c182e8c50efd', 'ZXC09V', 466, 14, 28, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('6318ab92-6590-4f5a-b8d4-4118091a1ff4', 'ZXC09V', 227, 461, 1000, '2d463773-5582-4e7b-be93-e883c3521f53');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('087292de-104c-4054-af49-98a7cfb1782e', 'ZXC09V', 252, 26, 172, 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('847ba8c0-f546-4bca-a61d-f7ed64bfc22c', 'QWE45P', 1, 656, 918, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('579286a9-50c5-46ad-acab-319c0fe5194d', 'BTR78Y', 289, 17, 574, 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('903de560-4601-4d42-97c4-87afb55803ce', 'BTR78Y', 330, 869, 245, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "user_stock" ("id", "token", "totalShares", "availableShares", "pricePerShare", "userId") VALUES ('1736a883-4f5c-43e2-9f2c-f2fd65ad232f', 'ASD67F', 57, 665, 273, '2d463773-5582-4e7b-be93-e883c3521f53');

INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('336f8e5d-5680-4a47-af31-3852832db05d', 441, 775, '903de560-4601-4d42-97c4-87afb55803ce', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('e2831d91-3c7e-4bd5-92f9-8b3e922c5382', 385, 66, '734dc0b7-a784-4981-8e50-7d131a028abd', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('e52c74be-31b3-461e-9886-50096036573d', 424, 164, 'e46d3efc-1a99-40ac-bf81-c182e8c50efd', 'a456212f-c782-4cd3-a8cc-982db73c40b5', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('fcfbdf15-33b5-46bd-bd2a-f6882762e925', 32, 83, 'fcd0b092-7a32-4e3c-b8d2-1816dd297213', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('668659f8-bd69-4702-92cc-c568fe82f487', 708, 194, '579286a9-50c5-46ad-acab-319c0fe5194d', '09e03c7e-8963-4577-80f6-f45a84783a20', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('6b3fb8ec-032e-4007-8e17-77e042a042bc', 581, 884, 'e46d3efc-1a99-40ac-bf81-c182e8c50efd', 'a456212f-c782-4cd3-a8cc-982db73c40b5', '09e03c7e-8963-4577-80f6-f45a84783a20');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('0b295689-c015-4f58-8d9f-07fe0c9fe965', 627, 437, '734dc0b7-a784-4981-8e50-7d131a028abd', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('a2403b15-0ecc-48b9-aa4f-4f53a13014fd', 231, 132, '6318ab92-6590-4f5a-b8d4-4118091a1ff4', '2d463773-5582-4e7b-be93-e883c3521f53', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('5b1ae580-9464-4e6f-a33a-2ed794094a89', 531, 310, '734dc0b7-a784-4981-8e50-7d131a028abd', 'bd5030a4-2b4f-40c1-8968-b13b58f97ce8', '50ec9851-d430-41f3-af1e-82510eb3d6ec');
INSERT INTO "stock_trade" ("id", "shares", "pricePerShare", "userStockId", "buyerId", "sellerId") VALUES ('2e18afd4-9855-41bc-8db3-b30b819872b9', 141, 971, '734dc0b7-a784-4981-8e50-7d131a028abd', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8', 'd6eb6637-d0b6-470a-bb42-b33edd2198c8');

INSERT INTO "post_data" ("id", "content", "userId") VALUES ('c761b05c-480a-4a6f-9877-941a37f8cf26', 'httpsexample.comimage2.jpg', 'a9b3986e-eca4-4d32-9f13-b127f093d3c3');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('37186a3c-9f2a-493d-9676-508977d9e42f', 'httpsexample.comvideo1.mp4', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('a8cba951-213c-47e8-a8eb-320cd0154b5e', 'httpsexample.comvideo2.mp4', '50ec9851-d430-41f3-af1e-82510eb3d6ec');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('a2adf174-60a9-435f-beab-4f863660a240', 'httpsexample.comimage3.jpg', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('e7ba6092-4e5b-475a-b973-7e848e8efd5d', 'httpsexample.comimage3.jpg', 'a456212f-c782-4cd3-a8cc-982db73c40b5');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('0590d45d-02de-44a7-bdc0-84f5914d3535', 'httpsexample.comimage3.jpg', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('8feefdba-36bf-4043-a469-50edb4d5dca5', 'httpsexample.comimage2.jpg', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('b3debece-a516-452b-a73c-2931f314b8c3', 'httpsexample.comimage1.jpg', 'a4967402-cfa5-4b1c-b6c2-3dc5249051ad');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('fde40008-1898-494a-9ed8-8f6af16089c3', 'httpsexample.comvideo1.mp4', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "post_data" ("id", "content", "userId") VALUES ('fe3ebbbb-145f-4b07-a3fd-ff7269ee8567', 'httpsexample.comimage3.jpg', '09e03c7e-8963-4577-80f6-f45a84783a20');
    `,
      )
    } catch (error) {
      // ignore
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
