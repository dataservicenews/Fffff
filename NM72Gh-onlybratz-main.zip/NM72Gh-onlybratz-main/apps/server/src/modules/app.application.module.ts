import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { ProfileApplicationModule } from './profile/application'

import { ContentApplicationModule } from './content/application'

import { ChatApplicationModule } from './chat/application'

import { MessageApplicationModule } from './message/application'

import { VoteApplicationModule } from './vote/application'

import { UserStockApplicationModule } from './userStock/application'

import { StockTradeApplicationModule } from './stockTrade/application'

import { PostDataApplicationModule } from './postData/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,

    ProfileApplicationModule,

    ContentApplicationModule,

    ChatApplicationModule,

    MessageApplicationModule,

    VoteApplicationModule,

    UserStockApplicationModule,

    StockTradeApplicationModule,

    PostDataApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
