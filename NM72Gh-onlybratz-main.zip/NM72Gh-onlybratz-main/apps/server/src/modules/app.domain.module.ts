import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { ProfileDomainModule } from './profile/domain'

import { ContentDomainModule } from './content/domain'

import { ChatDomainModule } from './chat/domain'

import { MessageDomainModule } from './message/domain'

import { VoteDomainModule } from './vote/domain'

import { UserStockDomainModule } from './userStock/domain'

import { StockTradeDomainModule } from './stockTrade/domain'

import { PostDataDomainModule } from './postData/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    ProfileDomainModule,

    ContentDomainModule,

    ChatDomainModule,

    MessageDomainModule,

    VoteDomainModule,

    UserStockDomainModule,

    StockTradeDomainModule,

    PostDataDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
