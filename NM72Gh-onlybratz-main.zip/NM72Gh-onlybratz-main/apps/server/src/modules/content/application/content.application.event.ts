export namespace ContentApplicationEvent {
  export namespace ContentCreated {
    export const key = 'content.application.content.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
