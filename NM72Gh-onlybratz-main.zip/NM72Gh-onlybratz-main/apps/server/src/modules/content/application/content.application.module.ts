import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ContentDomainModule } from '../domain'
import { ContentController } from './content.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ContentByUserController } from './contentByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, ContentDomainModule, UserDomainModule],
  controllers: [ContentController, ContentByUserController],
  providers: [],
})
export class ContentApplicationModule {}
