import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Content, ContentDomainFacade } from '@server/modules/content/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ContentApplicationEvent } from './content.application.event'
import { ContentCreateDto, ContentUpdateDto } from './content.dto'

@Controller('/v1/contents')
export class ContentController {
  constructor(
    private eventService: EventService,
    private contentDomainFacade: ContentDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.contentDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ContentCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.contentDomainFacade.create(body)

    await this.eventService.emit<ContentApplicationEvent.ContentCreated.Payload>(
      ContentApplicationEvent.ContentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:contentId')
  async findOne(
    @Param('contentId') contentId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.contentDomainFacade.findOneByIdOrFail(
      contentId,
      queryOptions,
    )

    return item
  }

  @Patch('/:contentId')
  async update(
    @Param('contentId') contentId: string,
    @Body() body: ContentUpdateDto,
  ) {
    const item = await this.contentDomainFacade.findOneByIdOrFail(contentId)

    const itemUpdated = await this.contentDomainFacade.update(
      item,
      body as Partial<Content>,
    )
    return itemUpdated
  }

  @Delete('/:contentId')
  async delete(@Param('contentId') contentId: string) {
    const item = await this.contentDomainFacade.findOneByIdOrFail(contentId)

    await this.contentDomainFacade.delete(item)

    return item
  }
}
