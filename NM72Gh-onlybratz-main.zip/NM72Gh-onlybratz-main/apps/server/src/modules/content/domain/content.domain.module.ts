import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ContentDomainFacade } from './content.domain.facade'
import { Content } from './content.model'

@Module({
  imports: [TypeOrmModule.forFeature([Content]), DatabaseHelperModule],
  providers: [ContentDomainFacade, ContentDomainFacade],
  exports: [ContentDomainFacade],
})
export class ContentDomainModule {}
