import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationProfileSubscriber } from './subscribers/notification.profile.subscriber'

import { NotificationContentSubscriber } from './subscribers/notification.content.subscriber'

import { NotificationChatSubscriber } from './subscribers/notification.chat.subscriber'

import { NotificationMessageSubscriber } from './subscribers/notification.message.subscriber'

import { NotificationVoteSubscriber } from './subscribers/notification.vote.subscriber'

import { NotificationUserStockSubscriber } from './subscribers/notification.userStock.subscriber'

import { NotificationStockTradeSubscriber } from './subscribers/notification.stockTrade.subscriber'

import { NotificationPostDataSubscriber } from './subscribers/notification.postData.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationProfileSubscriber,

    NotificationContentSubscriber,

    NotificationChatSubscriber,

    NotificationMessageSubscriber,

    NotificationVoteSubscriber,

    NotificationUserStockSubscriber,

    NotificationStockTradeSubscriber,

    NotificationPostDataSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
