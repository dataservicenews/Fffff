export namespace StockTradeApplicationEvent {
  export namespace StockTradeCreated {
    export const key = 'stockTrade.application.stockTrade.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
