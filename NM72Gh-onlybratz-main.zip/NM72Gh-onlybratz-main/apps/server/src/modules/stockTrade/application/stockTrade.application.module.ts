import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { StockTradeDomainModule } from '../domain'
import { StockTradeController } from './stockTrade.controller'

import { UserStockDomainModule } from '../../../modules/userStock/domain'

import { StockTradeByUserStockController } from './stockTradeByUserStock.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { StockTradeByUserController } from './stockTradeByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    StockTradeDomainModule,

    UserStockDomainModule,

    UserDomainModule,
  ],
  controllers: [
    StockTradeController,

    StockTradeByUserStockController,

    StockTradeByUserController,
  ],
  providers: [],
})
export class StockTradeApplicationModule {}
