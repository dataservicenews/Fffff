import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  StockTrade,
  StockTradeDomainFacade,
} from '@server/modules/stockTrade/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { StockTradeApplicationEvent } from './stockTrade.application.event'
import { StockTradeCreateDto, StockTradeUpdateDto } from './stockTrade.dto'

@Controller('/v1/stockTrades')
export class StockTradeController {
  constructor(
    private eventService: EventService,
    private stockTradeDomainFacade: StockTradeDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.stockTradeDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: StockTradeCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.stockTradeDomainFacade.create(body)

    await this.eventService.emit<StockTradeApplicationEvent.StockTradeCreated.Payload>(
      StockTradeApplicationEvent.StockTradeCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:stockTradeId')
  async findOne(
    @Param('stockTradeId') stockTradeId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.stockTradeDomainFacade.findOneByIdOrFail(
      stockTradeId,
      queryOptions,
    )

    return item
  }

  @Patch('/:stockTradeId')
  async update(
    @Param('stockTradeId') stockTradeId: string,
    @Body() body: StockTradeUpdateDto,
  ) {
    const item =
      await this.stockTradeDomainFacade.findOneByIdOrFail(stockTradeId)

    const itemUpdated = await this.stockTradeDomainFacade.update(
      item,
      body as Partial<StockTrade>,
    )
    return itemUpdated
  }

  @Delete('/:stockTradeId')
  async delete(@Param('stockTradeId') stockTradeId: string) {
    const item =
      await this.stockTradeDomainFacade.findOneByIdOrFail(stockTradeId)

    await this.stockTradeDomainFacade.delete(item)

    return item
  }
}
