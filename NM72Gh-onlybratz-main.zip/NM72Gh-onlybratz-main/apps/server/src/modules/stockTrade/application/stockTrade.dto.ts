import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class StockTradeCreateDto {
  @IsNumber()
  @IsNotEmpty()
  shares: number

  @IsNumber()
  @IsNotEmpty()
  pricePerShare: number

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  userStockId?: string

  @IsString()
  @IsOptional()
  buyerId?: string

  @IsString()
  @IsOptional()
  sellerId?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class StockTradeUpdateDto {
  @IsNumber()
  @IsOptional()
  shares?: number

  @IsNumber()
  @IsOptional()
  pricePerShare?: number

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  userStockId?: string

  @IsString()
  @IsOptional()
  buyerId?: string

  @IsString()
  @IsOptional()
  sellerId?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
