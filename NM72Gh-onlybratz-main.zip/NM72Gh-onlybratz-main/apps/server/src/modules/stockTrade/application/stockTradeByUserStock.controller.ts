import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { StockTradeDomainFacade } from '@server/modules/stockTrade/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { StockTradeApplicationEvent } from './stockTrade.application.event'
import { StockTradeCreateDto } from './stockTrade.dto'

import { UserStockDomainFacade } from '../../userStock/domain'

@Controller('/v1/userStocks')
export class StockTradeByUserStockController {
  constructor(
    private userStockDomainFacade: UserStockDomainFacade,

    private stockTradeDomainFacade: StockTradeDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/userStock/:userStockId/stockTrades')
  async findManyUserStockId(
    @Param('userStockId') userStockId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.userStockDomainFacade.findOneByIdOrFail(userStockId)

    const items = await this.stockTradeDomainFacade.findManyByUserStock(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/userStock/:userStockId/stockTrades')
  async createByUserStockId(
    @Param('userStockId') userStockId: string,
    @Body() body: StockTradeCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userStockId }

    const item = await this.stockTradeDomainFacade.create(valuesUpdated)

    await this.eventService.emit<StockTradeApplicationEvent.StockTradeCreated.Payload>(
      StockTradeApplicationEvent.StockTradeCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
