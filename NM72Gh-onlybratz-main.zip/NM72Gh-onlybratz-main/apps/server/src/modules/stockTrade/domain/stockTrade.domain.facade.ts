import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { StockTrade } from './stockTrade.model'

import { UserStock } from '../../userStock/domain'

import { User } from '../../user/domain'

@Injectable()
export class StockTradeDomainFacade {
  constructor(
    @InjectRepository(StockTrade)
    private repository: Repository<StockTrade>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<StockTrade>): Promise<StockTrade> {
    return this.repository.save(values)
  }

  async update(
    item: StockTrade,
    values: Partial<StockTrade>,
  ): Promise<StockTrade> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: StockTrade): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<StockTrade> = {},
  ): Promise<StockTrade[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<StockTrade> = {},
  ): Promise<StockTrade> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByUserStock(
    item: UserStock,
    queryOptions: RequestHelper.QueryOptions<StockTrade> = {},
  ): Promise<StockTrade[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('userStock')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        userStockId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByBuyer(
    item: User,
    queryOptions: RequestHelper.QueryOptions<StockTrade> = {},
  ): Promise<StockTrade[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('buyer')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        buyerId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyBySeller(
    item: User,
    queryOptions: RequestHelper.QueryOptions<StockTrade> = {},
  ): Promise<StockTrade[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('seller')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sellerId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
