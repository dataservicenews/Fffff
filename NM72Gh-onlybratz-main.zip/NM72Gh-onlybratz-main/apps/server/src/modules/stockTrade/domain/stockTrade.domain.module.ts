import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { StockTradeDomainFacade } from './stockTrade.domain.facade'
import { StockTrade } from './stockTrade.model'

@Module({
  imports: [TypeOrmModule.forFeature([StockTrade]), DatabaseHelperModule],
  providers: [StockTradeDomainFacade, StockTradeDomainFacade],
  exports: [StockTradeDomainFacade],
})
export class StockTradeDomainModule {}
