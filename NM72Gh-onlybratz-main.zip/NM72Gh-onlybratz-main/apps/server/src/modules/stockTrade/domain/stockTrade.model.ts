import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { UserStock } from '../../../modules/userStock/domain'

import { User } from '../../../modules/user/domain'

@Entity()
export class StockTrade {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ColumnNumeric({ type: 'numeric' })
  shares: number

  @ColumnNumeric({ type: 'numeric' })
  pricePerShare: number

  @Column({})
  userStockId: string

  @ManyToOne(() => UserStock, parent => parent.stockTrades)
  @JoinColumn({ name: 'userStockId' })
  userStock?: UserStock

  @Column({})
  buyerId: string

  @ManyToOne(() => User, parent => parent.stockTradesAsBuyer)
  @JoinColumn({ name: 'buyerId' })
  buyer?: User

  @Column({})
  sellerId: string

  @ManyToOne(() => User, parent => parent.stockTradesAsSeller)
  @JoinColumn({ name: 'sellerId' })
  seller?: User

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
