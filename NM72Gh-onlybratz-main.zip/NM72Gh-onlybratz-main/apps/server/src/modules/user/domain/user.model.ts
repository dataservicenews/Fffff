import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Notification } from '../../../modules/notification/domain'

import { Profile } from '../../../modules/profile/domain'

import { Content } from '../../../modules/content/domain'

import { Chat } from '../../../modules/chat/domain'

import { Message } from '../../../modules/message/domain'

import { Vote } from '../../../modules/vote/domain'

import { UserStock } from '../../../modules/userStock/domain'

import { StockTrade } from '../../../modules/stockTrade/domain'

import { PostData } from '../../../modules/postData/domain'

export enum UserStatus {
  VERIFIED = 'VERIFIED',
  CREATED = 'CREATED',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ unique: true })
  email: string

  @Column()
  name: string

  @Column({ nullable: true })
  pictureUrl?: string

  @Column({ select: false, nullable: true })
  password: string

  @Column({ enum: UserStatus, default: UserStatus.VERIFIED })
  status: UserStatus

  @OneToMany(() => Profile, child => child.user)
  profiles?: Profile[]

  @OneToMany(() => Content, child => child.user)
  contents?: Content[]

  @OneToMany(() => Chat, child => child.sender)
  chatsAsSender?: Chat[]

  @OneToMany(() => Chat, child => child.receiver)
  chatsAsReceiver?: Chat[]

  @OneToMany(() => Message, child => child.sender)
  messagesAsSender?: Message[]

  @OneToMany(() => Vote, child => child.user)
  votes?: Vote[]

  @OneToMany(() => UserStock, child => child.user)
  userStocks?: UserStock[]

  @OneToMany(() => StockTrade, child => child.buyer)
  stockTradesAsBuyer?: StockTrade[]

  @OneToMany(() => StockTrade, child => child.seller)
  stockTradesAsSeller?: StockTrade[]

  @OneToMany(() => PostData, child => child.user)
  posts?: PostData[]

  @OneToMany(() => Notification, notification => notification.user)
  notifications?: Notification[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
