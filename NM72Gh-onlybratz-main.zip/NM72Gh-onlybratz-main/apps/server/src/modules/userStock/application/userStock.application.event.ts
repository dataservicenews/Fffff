export namespace UserStockApplicationEvent {
  export namespace UserStockCreated {
    export const key = 'userStock.application.userStock.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
