import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { UserStockDomainModule } from '../domain'
import { UserStockController } from './userStock.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { UserStockByUserController } from './userStockByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    UserStockDomainModule,

    UserDomainModule,
  ],
  controllers: [UserStockController, UserStockByUserController],
  providers: [],
})
export class UserStockApplicationModule {}
