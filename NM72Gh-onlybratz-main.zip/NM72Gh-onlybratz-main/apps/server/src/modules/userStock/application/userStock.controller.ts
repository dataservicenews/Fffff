import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  UserStock,
  UserStockDomainFacade,
} from '@server/modules/userStock/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { UserStockApplicationEvent } from './userStock.application.event'
import { UserStockCreateDto, UserStockUpdateDto } from './userStock.dto'

@Controller('/v1/userStocks')
export class UserStockController {
  constructor(
    private eventService: EventService,
    private userStockDomainFacade: UserStockDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.userStockDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: UserStockCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.userStockDomainFacade.create(body)

    await this.eventService.emit<UserStockApplicationEvent.UserStockCreated.Payload>(
      UserStockApplicationEvent.UserStockCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:userStockId')
  async findOne(
    @Param('userStockId') userStockId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.userStockDomainFacade.findOneByIdOrFail(
      userStockId,
      queryOptions,
    )

    return item
  }

  @Patch('/:userStockId')
  async update(
    @Param('userStockId') userStockId: string,
    @Body() body: UserStockUpdateDto,
  ) {
    const item = await this.userStockDomainFacade.findOneByIdOrFail(userStockId)

    const itemUpdated = await this.userStockDomainFacade.update(
      item,
      body as Partial<UserStock>,
    )
    return itemUpdated
  }

  @Delete('/:userStockId')
  async delete(@Param('userStockId') userStockId: string) {
    const item = await this.userStockDomainFacade.findOneByIdOrFail(userStockId)

    await this.userStockDomainFacade.delete(item)

    return item
  }
}
