import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class UserStockCreateDto {
  @IsString()
  @IsNotEmpty()
  token: string

  @IsNumber()
  @IsNotEmpty()
  totalShares: number

  @IsNumber()
  @IsNotEmpty()
  availableShares: number

  @IsNumber()
  @IsNotEmpty()
  pricePerShare: number

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string
}

export class UserStockUpdateDto {
  @IsString()
  @IsOptional()
  token?: string

  @IsNumber()
  @IsOptional()
  totalShares?: number

  @IsNumber()
  @IsOptional()
  availableShares?: number

  @IsNumber()
  @IsOptional()
  pricePerShare?: number

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string
}
