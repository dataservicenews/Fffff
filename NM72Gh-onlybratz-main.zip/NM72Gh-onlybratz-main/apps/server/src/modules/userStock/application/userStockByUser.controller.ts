import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { UserStockDomainFacade } from '@server/modules/userStock/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { UserStockApplicationEvent } from './userStock.application.event'
import { UserStockCreateDto } from './userStock.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class UserStockByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private userStockDomainFacade: UserStockDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/userStocks')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.userStockDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/userStocks')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: UserStockCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.userStockDomainFacade.create(valuesUpdated)

    await this.eventService.emit<UserStockApplicationEvent.UserStockCreated.Payload>(
      UserStockApplicationEvent.UserStockCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
