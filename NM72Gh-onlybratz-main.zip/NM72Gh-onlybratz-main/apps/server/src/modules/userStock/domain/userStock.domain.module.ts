import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { UserStockDomainFacade } from './userStock.domain.facade'
import { UserStock } from './userStock.model'

@Module({
  imports: [TypeOrmModule.forFeature([UserStock]), DatabaseHelperModule],
  providers: [UserStockDomainFacade, UserStockDomainFacade],
  exports: [UserStockDomainFacade],
})
export class UserStockDomainModule {}
