import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { StockTrade } from '../../../modules/stockTrade/domain'

@Entity()
export class UserStock {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  token: string

  @ColumnNumeric({ type: 'numeric' })
  totalShares: number

  @ColumnNumeric({ type: 'numeric' })
  availableShares: number

  @ColumnNumeric({ type: 'numeric' })
  pricePerShare: number

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.userStocks)
  @JoinColumn({ name: 'userId' })
  user?: User

  @OneToMany(() => StockTrade, child => child.userStock)
  stockTrades?: StockTrade[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
