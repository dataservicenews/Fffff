import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { VoteDomainModule } from '../domain'
import { VoteController } from './vote.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { VoteByUserController } from './voteByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, VoteDomainModule, UserDomainModule],
  controllers: [VoteController, VoteByUserController],
  providers: [],
})
export class VoteApplicationModule {}
