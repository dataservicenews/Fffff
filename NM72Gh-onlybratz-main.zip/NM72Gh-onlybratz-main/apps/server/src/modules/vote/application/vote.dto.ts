import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class VoteCreateDto {
  @IsNumber()
  @IsNotEmpty()
  weekOfYear: number

  @IsNumber()
  @IsNotEmpty()
  year: number

  @IsNumber()
  @IsOptional()
  voteCount?: number

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class VoteUpdateDto {
  @IsNumber()
  @IsOptional()
  weekOfYear?: number

  @IsNumber()
  @IsOptional()
  year?: number

  @IsNumber()
  @IsOptional()
  voteCount?: number

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
