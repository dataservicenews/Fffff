'use client'

import { useEffect, useState } from 'react'
import { Input, Button, List, Avatar, Typography, Row, Col } from 'antd'
import { SendOutlined } from '@ant-design/icons'
const { TextArea } = Input
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ChatConversationPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [messages, setMessages] = useState([])
  const [messageContent, setMessageContent] = useState('')
  const [chat, setChat] = useState(null)

  useEffect(() => {
    if (!userId || !params.id) return
    fetchChat()
  }, [userId, params.id])

  const fetchChat = async () => {
    try {
      const chatData = await Api.Chat.findManyBySenderId(userId, {
        includes: ['messages', 'receiver', 'sender'],
      })
      const currentChat = chatData.find(chat => chat.id === params.id)
      if (currentChat) {
        setChat(currentChat)
        setMessages(currentChat.messages || [])
      }
    } catch (error) {
      enqueueSnackbar('Failed to load chat data', { variant: 'error' })
    }
  }

  const handleSendMessage = async () => {
    if (!messageContent.trim()) return
    try {
      const newMessage = await Api.Message.createOneByChatId(chat.id, {
        content: messageContent,
        senderId: userId,
      })
      setMessages([...messages, newMessage])
      setMessageContent('')
    } catch (error) {
      enqueueSnackbar('Failed to send message', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center">
        <Col xs={24} sm={18} md={12}>
          <Title level={2}>Chat Conversation</Title>
          <Text type="secondary">
            Engage in text-based conversations and connect with others.
          </Text>
          <List
            itemLayout="horizontal"
            dataSource={messages}
            renderItem={item => (
              <List.Item>
                <List.Item.Meta
                  avatar={
                    <Avatar
                      src={
                        item.sender?.pictureUrl ||
                        'https://joeschmoe.io/api/v1/random'
                      }
                    />
                  }
                  title={
                    <a href={`/user/${item.senderId}`}>
                      {item.sender?.name || 'Anonymous'}
                    </a>
                  }
                  description={item.content}
                />
                <div>{dayjs(item.dateCreated).format('HH:mm')}</div>
              </List.Item>
            )}
          />
          <TextArea
            rows={4}
            value={messageContent}
            onChange={e => setMessageContent(e.target.value)}
          />
          <Button
            type="primary"
            icon={<SendOutlined />}
            onClick={handleSendMessage}
            style={{ marginTop: '10px' }}
          >
            Send
          </Button>
        </Col>
      </Row>
    </PageLayout>
  )
}
