'use client'

import React, { useEffect, useState } from 'react'
import { List, Avatar, Button, Typography, Card, Row, Col } from 'antd'
import { MessageOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ChatPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [chats, setChats] = useState([])

  useEffect(() => {
    if (userId) {
      Api.Chat.findManyBySenderId(userId, {
        includes: ['receiver', 'messages'],
      })
        .then(data => {
          setChats(data)
        })
        .catch(error => {
          enqueueSnackbar('Failed to load chats', { variant: 'error' })
          console.error('Failed to load chats:', error)
        })
    }
  }, [userId])

  const navigateToChat = chatId => {
    router.push(`/chat/${chatId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Your Chats</Title>
      <Text>Here you can find all your ongoing conversations.</Text>
      <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
        {chats.map(chat => (
          <Col key={chat.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              actions={[
                <Button
                  type="primary"
                  icon={<MessageOutlined />}
                  onClick={() => navigateToChat(chat.id)}
                >
                  Open Chat
                </Button>,
              ]}
            >
              <Card.Meta
                avatar={<Avatar src={chat.receiver?.pictureUrl} />}
                title={chat.receiver?.name}
                description={`Last message: ${chat.messages?.[0]?.content.substring(0, 30)}...`}
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
