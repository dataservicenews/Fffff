'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Button, Image, Row, Col, Space } from 'antd'
import { EyeOutlined, HeartOutlined, MessageOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ContentDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [content, setContent] = useState(null)

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const contentFound = await Api.Content.findOne(params.id, {
          includes: ['user'],
        })
        setContent(contentFound)
      } catch (error) {
        enqueueSnackbar('Failed to load content details', { variant: 'error' })
      }
    }

    fetchContent()
  }, [params.id])

  const handleBack = () => {
    router.push('/explore')
  }

  return (
    <PageLayout layout="narrow">
      <Button onClick={handleBack} style={{ marginBottom: 20 }}>
        Back to Explore
      </Button>
      {content ? (
        <Row justify="center">
          <Col xs={24} sm={12}>
            <Title level={2}>{content.user?.name || 'Unknown User'}</Title>
            <Text type="secondary">
              Published on {dayjs(content.dateCreated).format('DD MMM YYYY')}
            </Text>
            <div style={{ margin: '20px 0' }}>
              {content.type === 'image' ? (
                <Image
                  src={content.url}
                  alt="content"
                  style={{ maxWidth: '100%' }}
                />
              ) : (
                <video controls style={{ maxWidth: '100%' }}>
                  <source src={content.url} type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              )}
            </div>
            <Title level={4}>Description</Title>
            <Text>{content.description || 'No description provided.'}</Text>
            <Space style={{ marginTop: 20 }}>
              <Button
                icon={<EyeOutlined />}
                onClick={() =>
                  enqueueSnackbar('View clicked', { variant: 'info' })
                }
              >
                View
              </Button>
              <Button
                icon={<HeartOutlined />}
                onClick={() =>
                  enqueueSnackbar('Like clicked', { variant: 'info' })
                }
              >
                Like
              </Button>
              <Button
                icon={<MessageOutlined />}
                onClick={() => router.push(`/chat/${content.userId}`)}
              >
                Message
              </Button>
            </Space>
          </Col>
        </Row>
      ) : (
        <Text>Loading...</Text>
      )}
    </PageLayout>
  )
}
