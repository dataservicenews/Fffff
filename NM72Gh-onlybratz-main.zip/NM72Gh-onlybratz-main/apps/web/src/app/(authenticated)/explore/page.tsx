'use client'

import React, { useEffect, useState } from 'react'
import { Card, Col, Row, Typography, Avatar, Space } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ExploreUsersPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [profiles, setProfiles] = useState([])

  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        const profilesFound = await Api.Profile.findMany({ includes: ['user'] })
        setProfiles(profilesFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch profiles', { variant: 'error' })
      }
    }

    fetchProfiles()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Explore Users</Title>
      <Text>Discover and view profiles of other users on the platform.</Text>
      <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
        {profiles?.map(profile => (
          <Col key={profile.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              onClick={() => router.push(`/user/${profile.userId}`)}
              cover={
                profile.profilePictureUrl ? (
                  <img alt="profile" src={profile.profilePictureUrl} />
                ) : (
                  <Avatar size={128} icon={<UserOutlined />} />
                )
              }
            >
              <Card.Meta
                title={profile.username || 'Unknown User'}
                description={
                  <Space direction="vertical">
                    <Text>{profile.bio || 'No bio available'}</Text>
                    <Text type="secondary">
                      Joined {dayjs(profile.dateCreated).format('MMMM D, YYYY')}
                    </Text>
                  </Space>
                }
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
