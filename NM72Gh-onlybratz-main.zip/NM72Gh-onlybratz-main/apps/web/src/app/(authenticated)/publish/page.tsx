'use client'

import React, { useState } from 'react'
import { Upload, Button, Typography, Modal, Input, Grid } from 'antd'
import {
  UploadOutlined,
  PictureOutlined,
  VideoCameraOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
const { useBreakpoint } = Grid
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function PublishContentPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const screens = useBreakpoint()

  const [fileList, setFileList] = useState([])
  const [description, setDescription] = useState('')
  const [isModalVisible, setIsModalVisible] = useState(false)

  const handleUpload = async options => {
    const { file } = options
    try {
      const url = await Api.Upload.upload(file)
      setFileList(fileList => [
        ...fileList,
        { url: url, status: 'done', type: file.type },
      ])
      enqueueSnackbar('File uploaded successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Upload failed', { variant: 'error' })
    }
  }

  const handleSubmit = async () => {
    try {
      const type = fileList[0]?.type.startsWith('image') ? 'image' : 'video'
      const values = { type, url: fileList[0]?.url, description }
      await Api.Content.createOneByUserId(userId, values)
      enqueueSnackbar('Content published successfully', { variant: 'success' })
      setIsModalVisible(false)
      setDescription('')
      setFileList([])
    } catch (error) {
      enqueueSnackbar('Failed to publish content', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout={screens.xs ? 'wide' : 'narrow'}>
      <Title level={2}>Publish Your Content</Title>
      <Text>Share your amazing images or videos with the world.</Text>
      <Upload
        fileList={fileList}
        customRequest={handleUpload}
        maxCount={1}
        onRemove={() => setFileList([])}
        accept="image/*,video/*"
        beforeUpload={() => false} // Prevent auto upload
      >
        <Button icon={<UploadOutlined />}>Select File</Button>
      </Upload>
      {fileList.length > 0 && (
        <Button
          type="primary"
          onClick={() => setIsModalVisible(true)}
          style={{ marginTop: 16 }}
          icon={
            fileList[0]?.type.startsWith('image') ? (
              <PictureOutlined />
            ) : (
              <VideoCameraOutlined />
            )
          }
        >
          Publish
        </Button>
      )}
      <Modal
        title="Publish Content"
        visible={isModalVisible}
        onOk={handleSubmit}
        onCancel={() => setIsModalVisible(false)}
        okText="Publish"
      >
        <Input.TextArea
          rows={4}
          value={description}
          onChange={e => setDescription(e.target.value)}
          placeholder="Add a description to your content"
        />
      </Modal>
    </PageLayout>
  )
}
