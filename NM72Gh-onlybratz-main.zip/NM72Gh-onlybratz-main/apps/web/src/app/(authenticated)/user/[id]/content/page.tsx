'use client'

import React, { useEffect, useState } from 'react'
import { Card, Row, Col, Typography, Space } from 'antd'
import { PlayCircleOutlined, PictureOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UserContentPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = params.id // Using params to get userId from URL
  const { enqueueSnackbar } = useSnackbar()
  const [contents, setContents] = useState([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('User ID is missing', { variant: 'error' })
      return
    }

    const fetchContents = async () => {
      try {
        const contentsFound = await Api.Content.findManyByUserId(userId, {
          includes: ['user'],
        })
        setContents(contentsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch contents', { variant: 'error' })
      }
    }

    fetchContents()
  }, [userId])

  return (
    <PageLayout layout="narrow">
      <Space direction="vertical" size="large" style={{ width: '100%' }}>
        <Title level={2}>User Content</Title>
        <Text>Explore all the content shared by the user.</Text>
        <Row gutter={[16, 16]}>
          {contents?.map(content => (
            <Col key={content.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                hoverable
                cover={
                  content.type === 'video' ? (
                    <PlayCircleOutlined
                      style={{ fontSize: '40px', color: '#1890ff' }}
                    />
                  ) : (
                    <PictureOutlined
                      style={{ fontSize: '40px', color: '#1890ff' }}
                    />
                  )
                }
                onClick={() => router.push(`/content/${content.id}`)}
              >
                <Card.Meta
                  title={content.user?.name || 'Unknown User'}
                  description={
                    <>
                      <Text>{content.description || 'No description'}</Text>
                      <br />
                      <Text type="secondary">
                        {dayjs(content.dateCreated).format('DD MMM YYYY')}
                      </Text>
                    </>
                  }
                />
              </Card>
            </Col>
          ))}
        </Row>
      </Space>
    </PageLayout>
  )
}
