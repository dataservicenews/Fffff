'use client'

import React, { useEffect, useState } from 'react'
import { Button, Form, Input, Upload, Typography } from 'antd'
import {
  UserOutlined,
  MailOutlined,
  PictureOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function EditProfilePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userData = await Api.User.findOne(userId, {
          includes: ['profiles'],
        })
        setUser(userData)
        if (userData.profiles?.length) {
          setProfile(userData.profiles[0])
          form.setFieldsValue({
            email: userData.email,
            name: userData.name,
            username: userData.profiles[0].username,
            bio: userData.profiles[0].bio,
          })
        }
      } catch (error) {
        enqueueSnackbar('Failed to fetch user data', { variant: 'error' })
      }
    }

    if (userId) {
      fetchUserData()
    }
  }, [userId, form])

  const handleSave = async values => {
    try {
      await Api.User.updateOne(userId, {
        email: values.email,
        name: values.name,
      })

      if (profile) {
        await Api.Profile.updateOne(profile.id, {
          username: values.username,
          bio: values.bio,
        })
      }

      enqueueSnackbar('Profile updated successfully', { variant: 'success' })
      router.push(`/user/${userId}`)
    } catch (error) {
      enqueueSnackbar('Failed to update profile', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title>Edit Profile</Title>
      <Text>Edit your profile information below.</Text>
      <Form form={form} layout="vertical" onFinish={handleSave}>
        <Form.Item
          name="email"
          label="Email"
          rules={[{ required: true, message: 'Please input your email!' }]}
        >
          <Input prefix={<MailOutlined />} />
        </Form.Item>
        <Form.Item
          name="name"
          label="Name"
          rules={[{ required: true, message: 'Please input your name!' }]}
        >
          <Input prefix={<UserOutlined />} />
        </Form.Item>
        <Form.Item
          name="username"
          label="Username"
          rules={[{ required: true, message: 'Please input your username!' }]}
        >
          <Input prefix={<InfoCircleOutlined />} />
        </Form.Item>
        <Form.Item name="bio" label="Bio">
          <Input.TextArea rows={4} />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save Changes
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
