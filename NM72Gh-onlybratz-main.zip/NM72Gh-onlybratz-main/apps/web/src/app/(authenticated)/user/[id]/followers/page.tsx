'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Card, Avatar, Row, Col, Space } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FollowersPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [followers, setFollowers] = useState([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('You must be logged in to view this page', {
        variant: 'error',
      })
      router.push('/')
      return
    }

    const fetchFollowers = async () => {
      try {
        const user = await Api.User.findOne(userId, {
          includes: ['profiles', 'profiles.user'],
        })
        if (user?.profiles?.length) {
          // Assuming 'profiles.user' includes the followers
          setFollowers(user.profiles.map(profile => profile.user))
        }
      } catch (error) {
        enqueueSnackbar('Failed to load followers', { variant: 'error' })
      }
    }

    fetchFollowers()
  }, [userId, router])

  return (
    <PageLayout layout="narrow">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Title level={2}>Followers</Title>
        <Text>Explore the community that follows you.</Text>
        <Row gutter={[16, 16]}>
          {followers?.map((follower, index) => (
            <Col key={index} xs={24} sm={12} md={8} lg={6} xl={4}>
              <Card
                hoverable
                onClick={() => router.push(`/user/${follower.id}`)}
                cover={
                  follower.pictureUrl ? (
                    <img alt="follower" src={follower.pictureUrl} />
                  ) : (
                    <Avatar shape="square" size={200} icon={<UserOutlined />} />
                  )
                }
              >
                <Card.Meta
                  title={follower.name || 'Unknown'}
                  description={`Joined: ${dayjs(follower.dateCreated).format('DD/MM/YYYY')}`}
                />
              </Card>
            </Col>
          ))}
        </Row>
      </Space>
    </PageLayout>
  )
}
