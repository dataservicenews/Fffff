'use client'

import React, { useEffect, useState } from 'react'
import { Typography, List, Avatar, Button, Space } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FollowingPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [following, setFollowing] = useState([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('You must be logged in to view this page.', {
        variant: 'error',
      })
      router.push('/')
      return
    }

    const fetchFollowing = async () => {
      try {
        const user = await Api.User.findOne(userId, {
          includes: ['profiles', 'profiles.user'],
        })
        setFollowing(user.profiles?.map(profile => profile.user) || [])
      } catch (error) {
        enqueueSnackbar('Failed to fetch following users.', {
          variant: 'error',
        })
      }
    }

    fetchFollowing()
  }, [userId, router])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Following</Title>
      <Text>Users you are following.</Text>
      <List
        itemLayout="horizontal"
        dataSource={following}
        renderItem={user => (
          <List.Item
            actions={[
              <Button
                type="link"
                onClick={() => router.push(`/user/${user.id}`)}
              >
                View Profile
              </Button>,
            ]}
          >
            <List.Item.Meta
              avatar={
                <Avatar
                  src={user.pictureUrl || undefined}
                  icon={<UserOutlined />}
                />
              }
              title={
                <a onClick={() => router.push(`/user/${user.id}`)}>
                  {user.name}
                </a>
              }
              description={`Joined ${dayjs(user.dateCreated).format('MMM D, YYYY')}`}
            />
          </List.Item>
        )}
      />
    </PageLayout>
  )
}
