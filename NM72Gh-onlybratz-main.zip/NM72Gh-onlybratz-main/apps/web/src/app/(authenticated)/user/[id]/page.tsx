'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Avatar, Row, Col, Space, Image } from 'antd'
import { UserOutlined, PictureOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UserProfilePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { userId } = params
  const { enqueueSnackbar } = useSnackbar()
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [contents, setContents] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userFound = await Api.User.findOne(userId, {
          includes: ['profiles', 'contents'],
        })
        setUser(userFound)
        if (userFound.profiles?.length > 0) {
          setProfile(userFound.profiles[0])
        }
        if (userFound.contents?.length > 0) {
          setContents(userFound.contents)
        }
      } catch (error) {
        enqueueSnackbar('Failed to fetch user data', { variant: 'error' })
      }
    }

    fetchData()
  }, [userId])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>User Profile</Title>
      <Paragraph>
        Welcome to the user profile page. Here you can find personal
        information, bio, and a gallery of published content.
      </Paragraph>
      <Card>
        <Space direction="vertical" size="middle" style={{ display: 'flex' }}>
          <Avatar
            size={128}
            src={profile?.profilePictureUrl}
            icon={<UserOutlined />}
          />
          <Title level={3}>{profile?.username || 'No Username'}</Title>
          <Text>Email: {user?.email || 'No Email'}</Text>
          <Text>Status: {user?.status || 'No Status'}</Text>
          <Text>
            Member since: {dayjs(user?.dateCreated).format('DD MMM YYYY')}
          </Text>
          <Paragraph>{profile?.bio || 'No Bio'}</Paragraph>
        </Space>
      </Card>
      <Title level={2} style={{ marginTop: '20px' }}>
        Gallery
      </Title>
      <Row gutter={16}>
        {contents?.map(content => (
          <Col key={content.id} xs={24} sm={12} md={8} lg={6} xl={4}>
            <Card
              hoverable
              cover={<Image alt="content" src={content.url} />}
              onClick={() => router.push(`/content/${content.id}`)}
            >
              <Card.Meta
                avatar={<PictureOutlined />}
                title={dayjs(content.dateCreated).format('DD MMM YYYY')}
                description={content.description || 'No Description'}
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
