export interface MrbHtmlTheme {
  color: string
  background: string
}
