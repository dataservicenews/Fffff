export const ThemeCommon = {
  token: {
    linkDecoration: 'underline',
  },
  components: {
    Form: {
      itemMarginBottom: '22px',
    },
  },
}
