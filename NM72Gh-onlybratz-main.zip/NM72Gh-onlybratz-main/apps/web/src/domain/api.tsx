import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { ProfileApi } from './profile/profile.api'

import { ContentApi } from './content/content.api'

import { ChatApi } from './chat/chat.api'

import { MessageApi } from './message/message.api'

import { VoteApi } from './vote/vote.api'

import { UserStockApi } from './userStock/userStock.api'

import { StockTradeApi } from './stockTrade/stockTrade.api'

import { PostDataApi } from './postData/postData.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Profile extends ProfileApi {}

  export class Content extends ContentApi {}

  export class Chat extends ChatApi {}

  export class Message extends MessageApi {}

  export class Vote extends VoteApi {}

  export class UserStock extends UserStockApi {}

  export class StockTrade extends StockTradeApi {}

  export class PostData extends PostDataApi {}
}
