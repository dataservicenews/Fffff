import { User } from '../user'

import { Message } from '../message'

export class Chat {
  id: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  senderId: string

  sender?: User

  receiverId: string

  receiver?: User

  messages?: Message[]
}
