import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Content } from './content.model'

export class ContentApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Content>,
  ): Promise<Content[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/contents${buildOptions}`)
  }

  static findOne(
    contentId: string,
    queryOptions?: ApiHelper.QueryOptions<Content>,
  ): Promise<Content> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/contents/${contentId}${buildOptions}`)
  }

  static createOne(values: Partial<Content>): Promise<Content> {
    return HttpService.api.post(`/v1/contents`, values)
  }

  static updateOne(
    contentId: string,
    values: Partial<Content>,
  ): Promise<Content> {
    return HttpService.api.patch(`/v1/contents/${contentId}`, values)
  }

  static deleteOne(contentId: string): Promise<void> {
    return HttpService.api.delete(`/v1/contents/${contentId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Content>,
  ): Promise<Content[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/contents${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Content>,
  ): Promise<Content> {
    return HttpService.api.post(`/v1/users/user/${userId}/contents`, values)
  }
}
