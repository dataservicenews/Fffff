import { User } from '../user'

export class Content {
  id: string

  type: string

  url: string

  description?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
