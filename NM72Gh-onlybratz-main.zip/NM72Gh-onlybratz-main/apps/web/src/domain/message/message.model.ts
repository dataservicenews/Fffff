import { Chat } from '../chat'

import { User } from '../user'

export class Message {
  id: string

  content: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  chatId: string

  chat?: Chat

  senderId: string

  sender?: User
}
