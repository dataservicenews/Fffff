import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Profile as ProfileModel } from './profile/profile.model'

import { Content as ContentModel } from './content/content.model'

import { Chat as ChatModel } from './chat/chat.model'

import { Message as MessageModel } from './message/message.model'

import { Vote as VoteModel } from './vote/vote.model'

import { UserStock as UserStockModel } from './userStock/userStock.model'

import { StockTrade as StockTradeModel } from './stockTrade/stockTrade.model'

import { PostData as PostDataModel } from './postData/postData.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Profile extends ProfileModel {}

  export class Content extends ContentModel {}

  export class Chat extends ChatModel {}

  export class Message extends MessageModel {}

  export class Vote extends VoteModel {}

  export class UserStock extends UserStockModel {}

  export class StockTrade extends StockTradeModel {}

  export class PostData extends PostDataModel {}
}
