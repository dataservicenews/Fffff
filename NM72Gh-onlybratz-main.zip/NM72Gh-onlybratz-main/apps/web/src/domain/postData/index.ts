export * from './postData.api'
export * from './postData.model'
