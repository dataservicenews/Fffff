import { User } from '../user'

export class PostData {
  id: string

  content: string

  dateCreated: string

  dateUpdated: string

  userId: string

  user?: User

  dateDeleted: string
}
