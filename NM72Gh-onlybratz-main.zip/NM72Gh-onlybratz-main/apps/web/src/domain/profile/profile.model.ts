import { User } from '../user'

export class Profile {
  id: string

  username?: string

  bio?: string

  profilePictureUrl?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
