import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { StockTrade } from './stockTrade.model'

export class StockTradeApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<StockTrade>,
  ): Promise<StockTrade[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/stockTrades${buildOptions}`)
  }

  static findOne(
    stockTradeId: string,
    queryOptions?: ApiHelper.QueryOptions<StockTrade>,
  ): Promise<StockTrade> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/stockTrades/${stockTradeId}${buildOptions}`)
  }

  static createOne(values: Partial<StockTrade>): Promise<StockTrade> {
    return HttpService.api.post(`/v1/stockTrades`, values)
  }

  static updateOne(
    stockTradeId: string,
    values: Partial<StockTrade>,
  ): Promise<StockTrade> {
    return HttpService.api.patch(`/v1/stockTrades/${stockTradeId}`, values)
  }

  static deleteOne(stockTradeId: string): Promise<void> {
    return HttpService.api.delete(`/v1/stockTrades/${stockTradeId}`)
  }

  static findManyByUserStockId(
    userStockId: string,
    queryOptions?: ApiHelper.QueryOptions<StockTrade>,
  ): Promise<StockTrade[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/userStocks/userStock/${userStockId}/stockTrades${buildOptions}`,
    )
  }

  static createOneByUserStockId(
    userStockId: string,
    values: Partial<StockTrade>,
  ): Promise<StockTrade> {
    return HttpService.api.post(
      `/v1/userStocks/userStock/${userStockId}/stockTrades`,
      values,
    )
  }

  static findManyByBuyerId(
    buyerId: string,
    queryOptions?: ApiHelper.QueryOptions<StockTrade>,
  ): Promise<StockTrade[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/buyer/${buyerId}/stockTrades${buildOptions}`,
    )
  }

  static createOneByBuyerId(
    buyerId: string,
    values: Partial<StockTrade>,
  ): Promise<StockTrade> {
    return HttpService.api.post(
      `/v1/users/buyer/${buyerId}/stockTrades`,
      values,
    )
  }

  static findManyBySellerId(
    sellerId: string,
    queryOptions?: ApiHelper.QueryOptions<StockTrade>,
  ): Promise<StockTrade[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/seller/${sellerId}/stockTrades${buildOptions}`,
    )
  }

  static createOneBySellerId(
    sellerId: string,
    values: Partial<StockTrade>,
  ): Promise<StockTrade> {
    return HttpService.api.post(
      `/v1/users/seller/${sellerId}/stockTrades`,
      values,
    )
  }
}
