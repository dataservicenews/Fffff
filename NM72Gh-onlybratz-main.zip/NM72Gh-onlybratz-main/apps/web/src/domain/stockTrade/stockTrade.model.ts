import { UserStock } from '../userStock'

import { User } from '../user'

export class StockTrade {
  id: string

  shares: number

  pricePerShare: number

  dateCreated: string

  userStockId: string

  userStock?: UserStock

  buyerId: string

  buyer?: User

  sellerId: string

  seller?: User

  dateDeleted: string

  dateUpdated: string
}
