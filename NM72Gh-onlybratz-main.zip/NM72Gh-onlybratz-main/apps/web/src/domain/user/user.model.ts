import { Notification } from '../notification'

import { Profile } from '../profile'

import { Content } from '../content'

import { Chat } from '../chat'

import { Message } from '../message'

import { Vote } from '../vote'

import { UserStock } from '../userStock'

import { StockTrade } from '../stockTrade'

import { PostData } from '../postData'

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string
  email: string
  status: UserStatus
  name: string
  pictureUrl: string
  password: string
  dateCreated: string
  dateUpdated: string
  notifications?: Notification[]

  profiles?: Profile[]

  contents?: Content[]

  chatsAsSender?: Chat[]

  chatsAsReceiver?: Chat[]

  messagesAsSender?: Message[]

  votes?: Vote[]

  userStocks?: UserStock[]

  stockTradesAsBuyer?: StockTrade[]

  stockTradesAsSeller?: StockTrade[]

  posts?: PostData[]
}
