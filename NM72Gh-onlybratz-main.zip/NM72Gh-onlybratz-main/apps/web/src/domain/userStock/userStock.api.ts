import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { UserStock } from './userStock.model'

export class UserStockApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<UserStock>,
  ): Promise<UserStock[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/userStocks${buildOptions}`)
  }

  static findOne(
    userStockId: string,
    queryOptions?: ApiHelper.QueryOptions<UserStock>,
  ): Promise<UserStock> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/userStocks/${userStockId}${buildOptions}`)
  }

  static createOne(values: Partial<UserStock>): Promise<UserStock> {
    return HttpService.api.post(`/v1/userStocks`, values)
  }

  static updateOne(
    userStockId: string,
    values: Partial<UserStock>,
  ): Promise<UserStock> {
    return HttpService.api.patch(`/v1/userStocks/${userStockId}`, values)
  }

  static deleteOne(userStockId: string): Promise<void> {
    return HttpService.api.delete(`/v1/userStocks/${userStockId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<UserStock>,
  ): Promise<UserStock[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/userStocks${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<UserStock>,
  ): Promise<UserStock> {
    return HttpService.api.post(`/v1/users/user/${userId}/userStocks`, values)
  }
}
