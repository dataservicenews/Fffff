import { User } from '../user'

import { StockTrade } from '../stockTrade'

export class UserStock {
  id: string

  token: string

  totalShares: number

  availableShares: number

  pricePerShare: number

  dateCreated: string

  dateUpdated: string

  userId: string

  user?: User

  dateDeleted: string

  stockTrades?: StockTrade[]
}
