import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Vote } from './vote.model'

export class VoteApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Vote>,
  ): Promise<Vote[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/votes${buildOptions}`)
  }

  static findOne(
    voteId: string,
    queryOptions?: ApiHelper.QueryOptions<Vote>,
  ): Promise<Vote> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/votes/${voteId}${buildOptions}`)
  }

  static createOne(values: Partial<Vote>): Promise<Vote> {
    return HttpService.api.post(`/v1/votes`, values)
  }

  static updateOne(voteId: string, values: Partial<Vote>): Promise<Vote> {
    return HttpService.api.patch(`/v1/votes/${voteId}`, values)
  }

  static deleteOne(voteId: string): Promise<void> {
    return HttpService.api.delete(`/v1/votes/${voteId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Vote>,
  ): Promise<Vote[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/users/user/${userId}/votes${buildOptions}`)
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Vote>,
  ): Promise<Vote> {
    return HttpService.api.post(`/v1/users/user/${userId}/votes`, values)
  }
}
