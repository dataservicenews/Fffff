import { User } from '../user'

export class Vote {
  id: string

  weekOfYear: number

  year: number

  voteCount: number

  userId: string

  user?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
